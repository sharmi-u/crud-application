import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;

import net.proteanit.sql.DbUtils;

import javax.swing.JTextField;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class CrudApp {

	private JFrame frame;
	private JTextField cid;
	private JTextField cno;
	private JTextField cname;
	private JTextField ino;
	private JTextField cname1;
	private JTextField idate;
	private JTextField textField_5;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrudApp window = new CrudApp();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CrudApp() {
		initialize();
		Connect();
		table_load();
	}
	
	PreparedStatement pat;
	Connection conn;
	ResultSet rs;
	public void Connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3304/crudapp", "root", "Sharmi#08");
		}
		catch(ClassNotFoundException ex){
			
		}
		catch(SQLException ex){
			
		}
	}

	public void table_load() {
		try {
			pat=conn.prepareStatement("select * from cdetails");
			rs=pat.executeQuery();
			table.setModel(DbUtils.resultSetToTableModel(rs));
		}
		catch(SQLException e){
			e.printStackTrace();
		}
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 789, 505);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Customer Invoice");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 25));
		lblNewLabel.setBounds(265, 11, 221, 49);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "Customer Details", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel.setBounds(36, 76, 321, 153);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Login ID");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(26, 32, 52, 14);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Name");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(45, 75, 33, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Phone");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(39, 118, 39, 14);
		panel.add(lblNewLabel_3);
		
		cid = new JTextField();
		cid.setBounds(127, 30, 173, 20);
		panel.add(cid);
		cid.setColumns(10);
		
		cno = new JTextField();
		cno.setColumns(10);
		cno.setBounds(127, 116, 173, 20);
		panel.add(cno);
		
		cname = new JTextField();
		cname.setColumns(10);
		cname.setBounds(127, 73, 173, 20);
		panel.add(cname);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Invoice details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(36, 266, 321, 153);
		frame.getContentPane().add(panel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Invoice No ");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1_1.setBounds(10, 32, 68, 14);
		panel_1.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_2_1 = new JLabel("Date");
		lblNewLabel_2_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2_1.setBounds(45, 75, 33, 14);
		panel_1.add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_3_1 = new JLabel("Name");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3_1.setBounds(39, 118, 39, 14);
		panel_1.add(lblNewLabel_3_1);
		
		ino = new JTextField();
		ino.setColumns(10);
		ino.setBounds(127, 30, 173, 20);
		panel_1.add(ino);
		
		cname1 = new JTextField();
		cname1.setColumns(10);
		cname1.setBounds(127, 116, 173, 20);
		panel_1.add(cname1);
		
		idate = new JTextField();
		idate.setColumns(10);
		idate.setBounds(127, 73, 173, 20);
		panel_1.add(idate);
		
		JLabel lblNewLabel_4 = new JLabel("Customer name");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setBounds(405, 76, 103, 15);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_5 = new JTextField();
		textField_5.setBounds(539, 73, 131, 20);
		frame.getContentPane().add(textField_5);
		textField_5.setColumns(10);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String Loginid,Name,Phoneno;
				Loginid=cid.getText();
				Name=cname.getText();
				Phoneno=cno.getText();
				try {
					pat=conn.prepareStatement("insert into cdetails(Loginid,Name,Phoneno)values(?,?,?)");
					pat.setString(1,Loginid);
					pat.setString(2,Name);
					pat.setString(2, Phoneno);
					pat.executeUpdate();
					JOptionPane.showMessageDialog(null, "Record Added!!!!!!");
					table_load();
					cid.setText(" ");
					cname.setText(" ");
					cno.setText(" ");
					cname.requestFocus();
				}
				catch(SQLException e1) {
					e1.printStackTrace();
				}
			}
		});
		btnNewButton.setBounds(46, 232, 89, 23);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("Exit");
		btnExit.setBounds(145, 232, 89, 23);
		frame.getContentPane().add(btnExit);
		
		JButton btnClear = new JButton("Clear");
		btnClear.setBounds(244, 232, 89, 23);
		frame.getContentPane().add(btnClear);
		
		table = new JTable();
		table.setBounds(495, 200, 53, -24);
		frame.getContentPane().add(table);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(367, 102, 384, 275);
		frame.getContentPane().add(scrollPane);
		
		table_1 = new JTable();
		scrollPane.setViewportView(table_1);
		
		JButton btnNewButton_1 = new JButton("Update");
		btnNewButton_1.setBounds(419, 396, 89, 23);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Delete");
		btnNewButton_1_1.setBounds(573, 396, 89, 23);
		frame.getContentPane().add(btnNewButton_1_1);
		
		JButton btnNewButton_2 = new JButton("Save");
		btnNewButton_2.setBounds(36, 430, 89, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnExit_1 = new JButton("Exit");
		btnExit_1.setBounds(145, 430, 89, 23);
		frame.getContentPane().add(btnExit_1);
		
		JButton btnClear_1 = new JButton("Clear");
		btnClear_1.setBounds(244, 430, 89, 23);
		frame.getContentPane().add(btnClear_1);
	}
}
